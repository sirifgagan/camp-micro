export interface SelectItem{
  label:string;
  value:string;
  selected:boolean;
}
